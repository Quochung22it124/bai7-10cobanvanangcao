<?php 
    session_start();
    if(isset($_POST['login'])){
        include('connect.php');
        $name = filter_input(INPUT_POST, 'username');
        $password = filter_input(INPUT_POST, 'password');
        $sl = "SELECT * FROM users WHERE Username='".$name."' and Password='".$password."'";
        $result = mysqli_query($connect, $sl);
        $row = mysqli_fetch_assoc($result);
        $kt = mysqli_num_rows($result);
        if($kt > 0){
            $_SESSION['username'] = $name;
            $_SESSION['password'] = $password;
            if(isset($_POST['remember']) and ($_POST['remember'] === 'on')){
                setcookie("username", $name, time()+60);
                setcookie("password", $password, time()+60);
            }
            echo "<script> alert('Login Successfull.');
                           location.href='trangquantriadmin.php'; 
                </script>";
            echo "Chao ban: ".$row['name']."<br>Pass cua ban la: ".$row['password'];
        }
        else{
            echo "<script> alert('Login Failed.');
                           location.href='index.php'; 
                </script>";
        }
    }
    if(isset($_POST['cancel'])){
        echo "<script> 
            location.href='index.php';
        </script>";
    }
?>